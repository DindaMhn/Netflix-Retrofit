package com.example.ktn_ak09c01.API.film

class Film(
    var id: String = "",
    var title: String = "",
    var duration: String = "",
    var image: String = "",
    var synopsis: String = ""
)